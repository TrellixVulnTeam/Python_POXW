linstor.protobuf\_to\_dict package
==================================

Module contents
---------------

A small Python library for creating dicts from protocol buffers.
Useful as an intermediate step before serialization (e.g. to JSON).

This library is used, as older protobuf versions don't have a JSON serializer yet.

.. automodule:: linstor.protobuf_to_dict
    :members:
    :undoc-members:
    :show-inheritance:
