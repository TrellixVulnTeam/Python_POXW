.. linstor documentation master file, created by
   sphinx-quickstart on Tue Jul 10 09:32:28 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to linstor's python api documentation!
==============================================

This documentation will help you getting started accessing the
Linstor controller with python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   linstor

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
